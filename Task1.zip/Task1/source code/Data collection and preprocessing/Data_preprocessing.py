import pandas as pd

# Load data into a Pandas DataFrame
data = pd.read_csv("social_media_data.csv")
# Remove duplicate rows
data = data.drop_duplicates()
# Remove rows with null values
data = data.dropna()
import re

# Function to clean text
def clean_text(text):
    # Convert text to lowercase
    text = text.lower()
    # Remove numbers
    text = re.sub(r'\d+', '', text)
    # Remove punctuation
    text = re.sub(r'[^\w\s]', '', text)
    # Remove whitespace
    text = text.strip()
    return text

# Apply text cleaning function to 'text' column
data['text'] = data['text'].apply(clean_text)
import nltk
nltk.download('punkt')
from nltk.tokenize import word_tokenize

# Function to tokenize text
def tokenize_text(text):
    tokens = word_tokenize(text)
    return tokens

# Apply tokenization function to 'text' column
data['text'] = data['text'].apply(tokenize_text)
nltk.download('stopwords')
from nltk.corpus import stopwords

# Get stop words
stop_words = set(stopwords.words('english'))

# Function to remove stop words
def remove_stopwords(tokens):
    filtered_tokens = [token for token in tokens if token not in stop_words]
    return filtered_tokens

# Apply stop word removal function to 'text' column
data['text'] = data['text'].apply(remove_stopwords)
from nltk.stem import SnowballStemmer

# Create stemmer object
stemmer = SnowballStemmer('english')

# Function to perform stemming
def stem_tokens(tokens):
    stemmed_tokens = [stemmer.stem(token) for token in tokens]
    return stemmed_tokens

# Apply stemming function to 'text' column
data['text'] = data['text'].apply(stem_tokens)
