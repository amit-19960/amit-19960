from sklearn.feature_extraction.text import CountVectorizer

# Initialize the CountVectorizer
vectorizer = CountVectorizer()

# Fit and transform the training data
X_train_encoded = vectorizer.fit_transform(X_train)

# Transform the validation data
X_val_encoded = vectorizer.transform(X_val)
