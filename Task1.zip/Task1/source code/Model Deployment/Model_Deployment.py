import joblib

# Save the trained model
joblib.dump(lr_model, 'sentiment_model.pkl')

# Load the model
model = joblib.load('sentiment_model.pkl')

# Make a prediction on new data
new_text = ["I love this product!"]
new_text_encoded = vectorizer.transform(new_text)
prediction = model.predict(new_text_encoded)

print(f"Prediction: {prediction}")
