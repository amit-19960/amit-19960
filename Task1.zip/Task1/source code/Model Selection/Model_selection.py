from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC

# Initialize the models
lr_model = LogisticRegression()
svm_model = SVC()

# Train the models
lr_model.fit(X_train_encoded, y_train)
svm_model.fit(X_train_encoded, y_train)
