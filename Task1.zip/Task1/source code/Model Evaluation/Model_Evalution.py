from sklearn.metrics import accuracy_score

# Make predictions on the validation data
lr_predictions = lr_model.predict(X_val_encoded)
svm_predictions = svm_model.predict(X_val_encoded)

# Compute the accuracy score
lr_accuracy = accuracy_score(y_val, lr_predictions)
svm_accuracy = accuracy_score(y_val, svm_predictions)

print(f"Logistic Regression Accuracy: {lr_accuracy}")
print(f"SVM Accuracy: {svm_accuracy}")
